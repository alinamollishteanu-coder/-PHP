# Marvel — индивидуальная работа (PHP + PostgreSQL)

Веб-приложение на базе вашего HTML/CSS проекта: каталог фильмов Marvel с регистрацией, поиском и админ-панелью.
Архитектура — простой MVC без фреймворков, пароли хешируются, БД работает в Docker.

## Запуск

Нужно: **Docker Desktop**, **PHP 8.1+** с расширением `pdo_pgsql`.

```bash
# 1. База данных (в папке проекта)
docker compose up -d

# 2. Сайт
php -S localhost:8000 -t public
```

Откройте http://localhost:8000

**Администратор по умолчанию:** `admin@marvel.local` / `Admin123!`

Если сайт пишет `could not find driver` — включите расширение в `php.ini`: раскомментируйте строки
`extension=pdo_pgsql` и `extension=pgsql` (путь к php.ini: `php --ini`), затем перезапустите `php -S`.
Проверка: `php -m` должен показывать `pdo_pgsql`.

Полный сброс базы (заново выполнится `db/init.sql`): `docker compose down -v`, затем `docker compose up -d`.

## Структура

```
docker-compose.yml     PostgreSQL в Docker
db/init.sql            таблицы + тестовые данные + админ
public/                то, что видит браузер
  index.php            единая точка входа и таблица маршрутов
  css/style.css        стили (из вашего проекта)
  js/validate.js       клиентская проверка форм
  img/                 картинки
app/
  config.php           настройки (БД, debug, captcha)
  core.php             БД, сессии, XSS/CSRF-защита, авторизация, шаблоны
  models/              UserModel, FilmModel — работа с БД (только подготовленные запросы)
  controllers/         Home, Auth, Film, Admin — логика страниц
  views/               HTML-шаблоны
storage/mail.log       сюда пишутся «отправленные» письма (восстановление пароля)
```

## Соответствие требованиям

| Требование | Где реализовано |
|---|---|
| Регистрация и вход | `AuthController::register/login`, страницы Register / Log in |
| Пароли в БД в виде хеша | `password_hash()` в `UserModel::create`, проверка `password_verify()` |
| Доп. задание: восстановление пароля | `AuthController::forgot/reset`: токен (в БД только SHA-256 хеш), срок 1 час, письмо пишется в `storage/mail.log` |
| Общедоступный раздел, 2–3 динамических элемента из БД | Главная: «Top Rated», «Upcoming», «Recently Added»; страница Films |
| Форма создания ресурса, 5+ полей разных типов | `film_form.php`: text, number, select, radio, number, textarea, url (7 полей) |
| Проверка на клиенте | HTML5-атрибуты + `public/js/validate.js` |
| Проверка на сервере, понятные ошибки | `FilmModel::validate`, `UserModel::validate` — ошибки под каждым полем |
| Форма поиска | Страница Films: название, категория, статус, годы (`FilmModel::search`) |
| Защищённый раздел только после входа | «Add film» и админка (`require_login()`, `require_admin()`) |
| Роль «администратор», 3–7 функций | Статистика; просмотр / редактирование / удаление фильмов; просмотр пользователей; смена роли; удаление пользователя; **создание новых администраторов** |
| Защита от внедрения кода | `e()` (htmlspecialchars) на всём выводе, PDO prepared statements, CSRF-токены во всех POST-формах |
| Сессии для доступа | `$_SESSION['user_id']`, `session_regenerate_id()` при входе; роль проверяется в БД на каждый запрос |
| CAPTCHA (необязательно) | Пример «a + b» на входе и регистрации (`captcha: false` в `config.php` отключает) |
| Модульная архитектура / MVC | `models/`, `controllers/`, `views/` |

## Заметки

- Восстановление пароля работает без настоящей почты: ссылка пишется в `storage/mail.log`, а при `debug => true` ещё и показывается на сайте. Для реальной отправки: `mail_real => true` и настроенный SMTP в PHP.
- Данные в `db/init.sql` (фильмы, годы, рейтинги, ожидаемые релизы) — примеры из вашего film.html; их можно править в админ-панели.
- Постеры берутся по ссылкам с amazon (как в вашем film.html); если ссылка не открывается, картинка просто не показывается.
