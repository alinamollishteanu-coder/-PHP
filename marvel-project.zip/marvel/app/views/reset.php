<h2>New password</h2>
<form method="post" action="<?= e(url('reset')) ?>" class="form" data-validate>
    <?= csrf_field() ?>
    <input type="hidden" name="token" value="<?= e($token) ?>">
    <div class="field">
        <label for="password">New password * (8+ characters, letter and digit)</label>
        <input type="password" id="password" name="password" required minlength="8" maxlength="72" autocomplete="new-password">
        <?= err($errors, 'password') ?>
    </div>
    <div class="field">
        <label for="password2">Repeat password *</label>
        <input type="password" id="password2" name="password2" required minlength="8" maxlength="72" autocomplete="new-password">
        <?= err($errors, 'password2') ?>
    </div>
    <div class="actions"><button type="submit" class="btn">Change password</button></div>
</form>
