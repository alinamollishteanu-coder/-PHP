<h2><?= e($heading) ?></h2>
<form method="post" action="<?= e($action) ?>" class="form">
    <?= csrf_field() ?>

    <div class="field">
        <label for="title">Title * (text)</label>
        <input type="text" id="title" name="title" value="<?= old($values, 'title') ?>" required minlength="2" maxlength="150">
        <?= err($errors, 'title') ?>
    </div>

    <div class="field">
        <label for="release_year">Release year * (number)</label>
        <input type="number" id="release_year" name="release_year" value="<?= old($values, 'release_year') ?>" required min="1939" max="2100">
        <?= err($errors, 'release_year') ?>
    </div>

    <div class="field">
        <label for="category">Category * (drop-down list)</label>
        <select id="category" name="category" required>
            <?php foreach (FilmModel::CATEGORIES as $key => $label): ?>
                <option value="<?= e($key) ?>" <?= ($values['category'] ?? '') === $key ? 'selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach ?>
        </select>
        <?= err($errors, 'category') ?>
    </div>

    <div class="field">
        <span class="label">Status * (radio buttons)</span>
        <?php foreach (FilmModel::STATUSES as $key => $label): ?>
            <label class="inline">
                <input type="radio" name="status" value="<?= e($key) ?>" required <?= ($values['status'] ?? '') === $key ? 'checked' : '' ?>>
                <?= e($label) ?>
            </label>
        <?php endforeach ?>
        <?= err($errors, 'status') ?>
    </div>

    <div class="field">
        <label for="rating">Rating, 0–10 (number, optional)</label>
        <input type="number" id="rating" name="rating" value="<?= old($values, 'rating') ?>" min="0" max="10" step="0.1">
        <?= err($errors, 'rating') ?>
    </div>

    <div class="field">
        <label for="description">Description * (text area, 10–2000 characters)</label>
        <textarea id="description" name="description" rows="5" required minlength="10" maxlength="2000"><?= old($values, 'description') ?></textarea>
        <?= err($errors, 'description') ?>
    </div>

    <div class="field">
        <label for="poster">Poster link (URL, optional)</label>
        <input type="url" id="poster" name="poster" value="<?= old($values, 'poster') ?>" maxlength="500" placeholder="https://...">
        <?= err($errors, 'poster') ?>
    </div>

    <div class="actions">
        <button type="submit" class="btn"><?= e($submit) ?></button>
        <button type="reset" class="btn btn-secondary">Reset</button>
    </div>
</form>
