<article>
    <h1>Marvel Creation Story</h1>

    <section>
        <h2>The Beginning of Marvel Comics</h2>
        <p>Marvel Comics started in 1939 as Timely Publications. But the Marvel we know today was really created in the 1960s by Stan Lee.</p>
    </section>

    <section>
        <h2>Stan Lee and His First Comic</h2>
        <p>Stan Lee's first superhero creation was the <strong>Human Torch</strong> in 1939. But his big breakthrough came in 1961 when he created the <strong>Fantastic Four</strong> with artist Jack Kirby.</p>
        <p>Stan Lee wanted to make superheroes more realistic. He gave them problems like normal people. Spider-Man had money troubles, the Hulk had anger issues, and the X-Men faced discrimination.</p>
    </section>

    <section>
        <h2>Important Early Characters</h2>
        <div class="projects-grid">
            <div class="project-item">
                <h3>Fantastic Four (1961)</h3>
                <p>Created by Stan Lee and Jack Kirby. This was Marvel's first superhero team.</p>
            </div>
            <div class="project-item">
                <h3>Spider-Man (1962)</h3>
                <p>Created by Stan Lee and Steve Ditko. Peter Parker was a teenager with everyday problems.</p>
            </div>
            <div class="project-item">
                <h3>X-Men (1963)</h3>
                <p>Created by Stan Lee and Jack Kirby. These mutants represented outsiders in society.</p>
            </div>
        </div>
    </section>

    <section>
        <h2>Marvel Today</h2>
        <p>Today, Marvel is part of The Walt Disney Company. Marvel movies are very popular all over the world. The Marvel Cinematic Universe (MCU) is one of the biggest movie series ever.</p>
        <p>Marvel still makes new comics, but now they also make movies, TV shows, video games, and merchandise. Characters created 60 years ago are now known by people everywhere.</p>
    </section>
</article>
