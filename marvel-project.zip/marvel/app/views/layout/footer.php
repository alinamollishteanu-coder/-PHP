        </main>
    </div>
</div>
<footer>
    <p>&copy; Marvel Universe Fan Page. All Marvel characters and related content are trademarks of Marvel Entertainment.</p>
    <p>Official Marvel website: <a href="https://www.marvel.com" target="_blank" rel="noopener noreferrer">www.marvel.com</a></p>
</footer>
</body>
</html>
