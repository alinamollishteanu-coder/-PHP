<?php $me = current_user(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title ?? 'Marvel') ?></title>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/validate.js" defer></script>
</head>
<body>
<header>M A R V E L</header>
<div class="globaldiv">
    <div class="globalnav">
        <nav>
            <div class="dropmain">
                <button class="dropmenu" type="button">≡</button>
                <div class="dropcont">
                    <a class="adr" href="<?= e(url('home')) ?>">Main</a>
                    <a class="adr" href="<?= e(url('history')) ?>">History</a>
                    <a class="adr" href="<?= e(url('films')) ?>">Films</a>
                    <?php if ($me): ?>
                        <a class="adr" href="<?= e(url('film_add')) ?>">Add film</a>
                        <?php if ($me['role'] === 'admin'): ?>
                            <a class="adr" href="<?= e(url('admin')) ?>">Admin panel</a>
                        <?php endif ?>
                        <a class="adr" href="<?= e(url('logout')) ?>">Log out</a>
                    <?php else: ?>
                        <a class="adr" href="<?= e(url('login')) ?>">Log in</a>
                        <a class="adr" href="<?= e(url('register')) ?>">Register</a>
                    <?php endif ?>
                </div>
            </div>
        </nav>
    </div>
    <div class="globalmain">
        <main>
            <?php if ($me): ?>
                <p class="who">Signed in as <strong><?= e($me['name'] . ' ' . $me['surname']) ?></strong> (<?= e($me['role']) ?>)</p>
            <?php endif ?>
            <?php foreach (take_flash() as $note): ?>
                <div class="alert alert-<?= e($note['type']) ?>">
                    <?= e($note['msg']) ?>
                    <?php if (!empty($note['link'])): ?>
                        <a href="<?= e($note['link']) ?>"><?= e($note['link']) ?></a>
                    <?php endif ?>
                </div>
            <?php endforeach ?>
