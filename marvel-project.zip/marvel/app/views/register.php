<h2>Registration</h2>
<form method="post" action="<?= e(url('register')) ?>" class="form" data-validate>
    <?= csrf_field() ?>
    <?php include VIEW_PATH . '/partials/user_fields.php'; ?>
    <?php include VIEW_PATH . '/partials/captcha.php'; ?>
    <div class="actions">
        <button type="submit" class="btn">Register</button>
        <button type="reset" class="btn btn-secondary">Reset</button>
    </div>
    <p>Already have an account? <a href="<?= e(url('login')) ?>">Log in</a></p>
</form>
