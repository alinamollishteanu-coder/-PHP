<h2>Films</h2>

<!-- Форма поиска (GET): находит фильмы по названию, категории, статусу и годам -->
<form method="get" action="index.php" class="search">
    <input type="hidden" name="page" value="films">
    <div class="field">
        <label for="q">Title</label>
        <input type="text" id="q" name="q" value="<?= old($f, 'q') ?>" maxlength="100" placeholder="e.g. Iron">
    </div>
    <div class="field">
        <label for="category">Category</label>
        <select id="category" name="category">
            <option value="">All</option>
            <?php foreach (FilmModel::CATEGORIES as $key => $label): ?>
                <option value="<?= e($key) ?>" <?= $f['category'] === $key ? 'selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach ?>
        </select>
    </div>
    <div class="field">
        <label for="status">Status</label>
        <select id="status" name="status">
            <option value="">All</option>
            <?php foreach (FilmModel::STATUSES as $key => $label): ?>
                <option value="<?= e($key) ?>" <?= $f['status'] === $key ? 'selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach ?>
        </select>
    </div>
    <div class="field">
        <label for="year_from">Year from</label>
        <input type="number" id="year_from" name="year_from" value="<?= old($f, 'year_from') ?>" min="1939" max="2100">
    </div>
    <div class="field">
        <label for="year_to">Year to</label>
        <input type="number" id="year_to" name="year_to" value="<?= old($f, 'year_to') ?>" min="1939" max="2100">
    </div>
    <div class="actions">
        <button type="submit" class="btn">Search</button>
        <a class="btn btn-secondary" href="<?= e(url('films')) ?>">Reset</a>
    </div>
</form>

<p>Found: <strong><?= count($films) ?></strong></p>

<div class="table-wrap">
    <table class="films-table">
        <thead>
        <tr><th>Poster</th><th>Title</th><th>Year</th><th>Category</th><th>Status</th><th>Rating</th><th>Description</th></tr>
        </thead>
        <tbody>
        <?php foreach ($films as $film): ?>
            <tr>
                <td class="poster-cell">
                    <?php if ($film['poster']): ?>
                        <img class="film-poster" src="<?= e($film['poster']) ?>" alt="<?= e($film['title']) ?>" loading="lazy"
                             referrerpolicy="no-referrer" onerror="this.style.display='none'">
                    <?php endif ?>
                </td>
                <td class="film-title"><?= e($film['title']) ?></td>
                <td><?= e($film['release_year']) ?></td>
                <td><?= e(FilmModel::CATEGORIES[$film['category']] ?? $film['category']) ?></td>
                <td><?= e(FilmModel::STATUSES[$film['status']] ?? $film['status']) ?></td>
                <td><?= $film['rating'] !== null ? '★ ' . e($film['rating']) : '—' ?></td>
                <td><?= e($film['description']) ?></td>
            </tr>
        <?php endforeach ?>
        <?php if (!$films): ?>
            <tr><td colspan="7">Nothing found. Try other search criteria.</td></tr>
        <?php endif ?>
        </tbody>
    </table>
</div>
