<h2><?= e($code) ?></h2>
<p><?= e($message) ?></p>
<p><a href="<?= e(url('home')) ?>">Back to the main page</a></p>
