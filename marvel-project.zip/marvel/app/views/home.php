<article>
    <div class="divhistory">
        <section class="history-section">
            <h2>The Birth of Marvel</h2>
            <p>Marvel Comics, originally known as Timely Publications, was founded in 1939 by Martin Goodman. The company's first comic book featured the debut of characters like the Human Torch and Namor the Sub-Mariner. However, Marvel truly revolutionized the industry in the early 1960s with the creation of the "Marvel Universe" by Stan Lee, Jack Kirby, and Steve Ditko.</p>
            <p>This new approach introduced interconnected stories, relatable characters with human flaws, and a shared universe where superheroes frequently interacted. Iconic characters like Spider-Man, the X-Men, Iron Man, Thor, the Hulk, and the Fantastic Four were born during this creative renaissance, changing comic book history forever.</p>
            <p>Marvel's unique storytelling formula — combining superhero action with real-world issues and personal drama — resonated deeply with readers and laid the foundation for what would become a global multimedia empire.</p>
        </section>
        <section class="sectfather">
            <img class="father" src="img/father.jpg" alt="Marvel's father">
            <p class="pfather">Marvel's father</p>
        </section>
    </div>

    <!-- Динамический блок 1: лучшие по рейтингу (из БД) -->
    <section class="popular-projects">
        <h2 class="mpp">Top Rated Projects</h2>
        <div class="projects-grid">
            <?php foreach ($top as $film): ?>
                <div class="project-item">
                    <h3><?= e($film['title']) ?></h3>
                    <p class="meta"><?= e($film['release_year']) ?> · <?= e(FilmModel::CATEGORIES[$film['category']] ?? $film['category']) ?> · ★ <?= e($film['rating']) ?></p>
                    <p><?= e(mb_strimwidth($film['description'], 0, 140, '…')) ?></p>
                </div>
            <?php endforeach ?>
            <?php if (!$top): ?><p class="mpp">No rated films yet.</p><?php endif ?>
        </div>
    </section>

    <!-- Динамический блок 2: ожидаемые релизы (из БД) -->
    <section class="upcoming-releases">
        <h2>Upcoming Marvel Releases</h2>
        <ul>
            <?php foreach ($upcoming as $film): ?>
                <li><strong><?= e($film['title']) ?></strong> (<?= e($film['release_year']) ?>) — <?= e($film['description']) ?></li>
            <?php endforeach ?>
            <?php if (!$upcoming): ?><li>No upcoming releases yet.</li><?php endif ?>
        </ul>
    </section>

    <!-- Динамический блок 3: последние добавленные (из БД) -->
    <section>
        <h2>Recently Added</h2>
        <ul class="plain">
            <?php foreach ($latest as $film): ?>
                <li><strong><?= e($film['title']) ?></strong> — <?= e($film['release_year']) ?>, added <?= e(substr($film['created_at'], 0, 10)) ?></li>
            <?php endforeach ?>
            <?php if (!$latest): ?><li>No films yet.</li><?php endif ?>
        </ul>
        <p><a href="<?= e(url('films')) ?>">See all films →</a></p>
    </section>
</article>
