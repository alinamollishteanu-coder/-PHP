<h2>Create administrator</h2>
<form method="post" action="<?= e(url('admin_user_add')) ?>" class="form" data-validate>
    <?= csrf_field() ?>
    <?php include VIEW_PATH . '/partials/user_fields.php'; ?>
    <div class="actions">
        <button type="submit" class="btn">Create administrator</button>
        <a class="btn btn-secondary" href="<?= e(url('admin_users')) ?>">Cancel</a>
    </div>
</form>
