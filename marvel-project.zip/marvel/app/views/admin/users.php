<h2>Manage users</h2>
<p><a class="btn" href="<?= e(url('admin_user_add')) ?>">+ Create administrator</a></p>

<div class="table-wrap">
    <table class="data-table">
        <thead>
        <tr><th>ID</th><th>Name</th><th>E-mail</th><th>Role</th><th>Registered</th><th>Actions</th></tr>
        </thead>
        <tbody>
        <?php foreach ($users as $u): ?>
            <tr>
                <td><?= e($u['id']) ?></td>
                <td><?= e($u['surname'] . ' ' . $u['name']) ?></td>
                <td><?= e($u['email']) ?></td>
                <td><?= e($u['role']) ?></td>
                <td><?= e(substr($u['created_at'], 0, 10)) ?></td>
                <td class="row-actions">
                    <?php if ((int)$u['id'] === (int)$me['id']): ?>
                        (you)
                    <?php else: ?>
                        <form method="post" action="<?= e(url('admin_user_role')) ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($u['id']) ?>">
                            <input type="hidden" name="role" value="<?= $u['role'] === 'admin' ? 'user' : 'admin' ?>">
                            <button type="submit" class="btn btn-small btn-secondary">
                                <?= $u['role'] === 'admin' ? 'Make user' : 'Make admin' ?>
                            </button>
                        </form>
                        <form method="post" action="<?= e(url('admin_user_delete')) ?>" onsubmit="return confirm('Delete this user?');">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($u['id']) ?>">
                            <button type="submit" class="btn btn-small btn-danger">Delete</button>
                        </form>
                    <?php endif ?>
                </td>
            </tr>
        <?php endforeach ?>
        </tbody>
    </table>
</div>
