<h2>Admin panel</h2>

<div class="stats">
    <div class="stat"><span class="num"><?= e($users['total']) ?></span> users</div>
    <div class="stat"><span class="num"><?= e($users['admins']) ?></span> administrators</div>
    <div class="stat"><span class="num"><?= e($films) ?></span> films</div>
</div>

<ul class="admin-menu">
    <li><a href="<?= e(url('admin_films')) ?>">Manage films</a> — view, edit and delete films</li>
    <li><a href="<?= e(url('film_add')) ?>">Add a film</a> — create a new record</li>
    <li><a href="<?= e(url('admin_users')) ?>">Manage users</a> — view users, change roles, delete accounts</li>
    <li><a href="<?= e(url('admin_user_add')) ?>">Create administrator</a> — new account with the admin role</li>
</ul>
