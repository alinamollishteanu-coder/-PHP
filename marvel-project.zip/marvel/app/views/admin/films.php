<h2>Manage films</h2>
<p><a class="btn" href="<?= e(url('film_add')) ?>">+ Add film</a></p>

<div class="table-wrap">
    <table class="data-table">
        <thead>
        <tr><th>ID</th><th>Title</th><th>Year</th><th>Category</th><th>Status</th><th>Rating</th><th>Added by</th><th>Actions</th></tr>
        </thead>
        <tbody>
        <?php foreach ($films as $film): ?>
            <tr>
                <td><?= e($film['id']) ?></td>
                <td><?= e($film['title']) ?></td>
                <td><?= e($film['release_year']) ?></td>
                <td><?= e(FilmModel::CATEGORIES[$film['category']] ?? $film['category']) ?></td>
                <td><?= e(FilmModel::STATUSES[$film['status']] ?? $film['status']) ?></td>
                <td><?= $film['rating'] !== null ? e($film['rating']) : '—' ?></td>
                <td><?= e($film['author'] ?? '—') ?></td>
                <td class="row-actions">
                    <a class="btn btn-small" href="<?= e(url('admin_film_edit', ['id' => $film['id']])) ?>">Edit</a>
                    <form method="post" action="<?= e(url('admin_film_delete')) ?>" onsubmit="return confirm('Delete this film?');">
                        <?= csrf_field() ?>
                        <input type="hidden" name="id" value="<?= e($film['id']) ?>">
                        <button type="submit" class="btn btn-small btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach ?>
        </tbody>
    </table>
</div>
