<h2>Password recovery</h2>
<p>Enter the e-mail you registered with. We will send you a link to set a new password.</p>
<form method="post" action="<?= e(url('forgot')) ?>" class="form">
    <?= csrf_field() ?>
    <div class="field">
        <label for="email">E-mail *</label>
        <input type="email" id="email" name="email" value="<?= old($values, 'email') ?>" required maxlength="100">
        <?= err($errors, 'email') ?>
    </div>
    <div class="actions"><button type="submit" class="btn">Send link</button></div>
    <p><a href="<?= e(url('login')) ?>">Back to log in</a></p>
</form>
