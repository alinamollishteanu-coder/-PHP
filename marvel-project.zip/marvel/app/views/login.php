<h2>Log in</h2>
<?php if (isset($errors['form'])): ?>
    <div class="alert alert-error"><?= e($errors['form']) ?></div>
<?php endif ?>
<form method="post" action="<?= e(url('login')) ?>" class="form">
    <?= csrf_field() ?>
    <div class="field">
        <label for="email">E-mail *</label>
        <input type="email" id="email" name="email" value="<?= old($values, 'email') ?>" required maxlength="100">
    </div>
    <div class="field">
        <label for="password">Password *</label>
        <input type="password" id="password" name="password" required autocomplete="current-password">
    </div>
    <?php include VIEW_PATH . '/partials/captcha.php'; ?>
    <div class="actions"><button type="submit" class="btn">Log in</button></div>
    <p><a href="<?= e(url('forgot')) ?>">Forgot your password?</a></p>
    <p>No account yet? <a href="<?= e(url('register')) ?>">Register</a></p>
</form>
