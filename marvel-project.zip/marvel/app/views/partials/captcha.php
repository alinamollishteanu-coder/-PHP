<?php if (captcha_enabled()): ?>
    <div class="field">
        <label for="captcha">Captcha: <?= e(captcha_question()) ?> = ? *</label>
        <input type="text" id="captcha" name="captcha" required inputmode="numeric" pattern="[0-9]{1,2}"
               autocomplete="off" title="Enter the sum of the two numbers">
        <?= err($errors, 'captcha') ?>
    </div>
<?php endif ?>
