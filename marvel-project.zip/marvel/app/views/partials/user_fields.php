<?php /* Общие поля пользователя: регистрация и создание администратора. Нужны $values и $errors. */ ?>
<div class="field">
    <label for="surname">Surname *</label>
    <input type="text" id="surname" name="surname" value="<?= old($values, 'surname') ?>" required
           minlength="2" maxlength="50" pattern="[A-Za-zА-Яа-яЁё\s\-]{2,50}"
           data-msg="Surname: 2–50 letters, spaces and hyphens only">
    <?= err($errors, 'surname') ?>
</div>
<div class="field">
    <label for="name">Name *</label>
    <input type="text" id="name" name="name" value="<?= old($values, 'name') ?>" required
           minlength="2" maxlength="50" pattern="[A-Za-zА-Яа-яЁё\s\-]{2,50}"
           data-msg="Name: 2–50 letters, spaces and hyphens only">
    <?= err($errors, 'name') ?>
</div>
<div class="field">
    <label for="email">E-mail *</label>
    <input type="email" id="email" name="email" value="<?= old($values, 'email') ?>" required maxlength="100">
    <?= err($errors, 'email') ?>
</div>
<div class="field">
    <label for="birth">Birthday *</label>
    <input type="date" id="birth" name="birth" value="<?= old($values, 'birth') ?>" required
           min="1900-01-01" max="<?= e(date('Y-m-d')) ?>">
    <?= err($errors, 'birth') ?>
</div>
<div class="field">
    <span class="label">Gender</span>
    <label class="inline"><input type="radio" name="gender" value="F" <?= ($values['gender'] ?? '') === 'F' ? 'checked' : '' ?>> F</label>
    <label class="inline"><input type="radio" name="gender" value="M" <?= ($values['gender'] ?? '') === 'M' ? 'checked' : '' ?>> M</label>
    <?= err($errors, 'gender') ?>
</div>
<div class="field">
    <label for="phone">Telephone</label>
    <input type="text" id="phone" name="phone" value="<?= old($values, 'phone') ?>" maxlength="16"
           pattern="\+?[0-9]{6,15}" data-msg="Phone: 6–15 digits, optionally starting with +">
    <?= err($errors, 'phone') ?>
</div>
<div class="field">
    <label for="password">Password * (8+ characters, letter and digit)</label>
    <input type="password" id="password" name="password" required minlength="8" maxlength="72" autocomplete="new-password">
    <?= err($errors, 'password') ?>
</div>
<div class="field">
    <label for="password2">Repeat password *</label>
    <input type="password" id="password2" name="password2" required minlength="8" maxlength="72" autocomplete="new-password">
    <?= err($errors, 'password2') ?>
</div>
