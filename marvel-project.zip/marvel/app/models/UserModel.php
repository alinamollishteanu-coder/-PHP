<?php
/**
 * Модель пользователей: работа с таблицей users и токенами восстановления пароля.
 */
class UserModel
{
    /** Найти пользователя по id. */
    public static function find(int $id): ?array
    {
        $st = db()->prepare('SELECT * FROM users WHERE id = :id');
        $st->execute([':id' => $id]);
        return $st->fetch() ?: null;
    }

    /** Найти пользователя по e-mail (регистр не важен). */
    public static function findByEmail(string $email): ?array
    {
        $st = db()->prepare('SELECT * FROM users WHERE email = :email');
        $st->execute([':email' => mb_strtolower($email)]);
        return $st->fetch() ?: null;
    }

    /** Список всех пользователей (для админки). */
    public static function all(): array
    {
        return db()->query('SELECT id, surname, name, email, role, created_at FROM users ORDER BY id')->fetchAll();
    }

    /** Количество пользователей и администраторов. */
    public static function counts(): array
    {
        return db()->query("SELECT COUNT(*) AS total, COUNT(*) FILTER (WHERE role = 'admin') AS admins FROM users")->fetch();
    }

    /**
     * Проверка пароля и его подтверждения.
     * @return array ошибки вида ['password' => '...', 'password2' => '...']
     */
    public static function passwordErrors(string $password, string $password2): array
    {
        $errors = [];
        if (strlen($password) < 8 || strlen($password) > 72) {
            $errors['password'] = 'Password must be 8–72 characters long.';
        } elseif (!preg_match('/[A-Za-z]/', $password) || !preg_match('/[0-9]/', $password)) {
            $errors['password'] = 'Password must contain at least one letter and one digit.';
        }
        if ($password !== $password2) {
            $errors['password2'] = 'Passwords do not match.';
        }
        return $errors;
    }

    /**
     * Проверка данных формы регистрации / создания администратора.
     * @param array $in сырые данные ($_POST)
     * @return array [очищенные данные, ошибки]
     */
    public static function validate(array $in): array
    {
        $d = [
            'surname'  => clean($in, 'surname'),
            'name'     => clean($in, 'name'),
            'email'    => mb_strtolower(clean($in, 'email')),
            'birth'    => clean($in, 'birth'),
            'gender'   => clean($in, 'gender'),
            'phone'    => clean($in, 'phone'),
            'password' => raw($in, 'password'),
        ];
        $errors = [];

        foreach (['surname' => 'Surname', 'name' => 'Name'] as $key => $label) {
            if (!preg_match('/^[\p{L}\s\-]{2,50}$/u', $d[$key])) {
                $errors[$key] = "$label must contain 2–50 letters (spaces and hyphens are allowed).";
            }
        }

        if (!filter_var($d['email'], FILTER_VALIDATE_EMAIL) || mb_strlen($d['email']) > 100) {
            $errors['email'] = 'Enter a valid e-mail address.';
        } elseif (self::findByEmail($d['email'])) {
            $errors['email'] = 'This e-mail is already registered.';
        }

        $date = DateTime::createFromFormat('Y-m-d', $d['birth']);
        if (!$date || $date->format('Y-m-d') !== $d['birth']) {
            $errors['birth'] = 'Enter a valid birthday.';
        } elseif ($d['birth'] > date('Y-m-d') || $d['birth'] < '1900-01-01') {
            $errors['birth'] = 'Birthday must be between 1900 and today.';
        }

        if ($d['gender'] !== '' && !in_array($d['gender'], ['M', 'F'], true)) {
            $errors['gender'] = 'Choose F or M.';
        }

        if ($d['phone'] !== '' && !preg_match('/^\+?[0-9]{6,15}$/', $d['phone'])) {
            $errors['phone'] = 'Phone must contain 6–15 digits (optionally starting with +).';
        }

        $errors += self::passwordErrors($d['password'], raw($in, 'password2'));

        return [$d, $errors];
    }

    /**
     * Создаёт пользователя. Пароль сохраняется только в виде хеша (password_hash).
     * @param array  $d    данные из validate()
     * @param string $role 'user' или 'admin'
     * @return int id нового пользователя
     */
    public static function create(array $d, string $role = 'user'): int
    {
        $st = db()->prepare(
            'INSERT INTO users (surname, name, email, birth, gender, phone, password_hash, role)
             VALUES (:surname, :name, :email, :birth, :gender, :phone, :hash, :role) RETURNING id'
        );
        $st->execute([
            ':surname' => $d['surname'],
            ':name'    => $d['name'],
            ':email'   => $d['email'],
            ':birth'   => $d['birth'],
            ':gender'  => $d['gender'] !== '' ? $d['gender'] : null,
            ':phone'   => $d['phone'] !== '' ? $d['phone'] : null,
            ':hash'    => password_hash($d['password'], PASSWORD_DEFAULT),
            ':role'    => $role,
        ]);
        return (int)$st->fetchColumn();
    }

    /** Меняет роль пользователя. */
    public static function setRole(int $id, string $role): void
    {
        $st = db()->prepare('UPDATE users SET role = :role WHERE id = :id');
        $st->execute([':role' => $role, ':id' => $id]);
    }

    /** Удаляет пользователя. */
    public static function delete(int $id): void
    {
        $st = db()->prepare('DELETE FROM users WHERE id = :id');
        $st->execute([':id' => $id]);
    }

    /** Устанавливает новый пароль (хеш) и удаляет токены восстановления. */
    public static function updatePassword(int $id, string $password): void
    {
        $st = db()->prepare('UPDATE users SET password_hash = :hash WHERE id = :id');
        $st->execute([':hash' => password_hash($password, PASSWORD_DEFAULT), ':id' => $id]);
        $st = db()->prepare('DELETE FROM password_resets WHERE user_id = :id');
        $st->execute([':id' => $id]);
    }

    /**
     * Создаёт токен восстановления пароля (действует 1 час).
     * В БД хранится только SHA-256 хеш токена, сам токен уходит пользователю.
     * @return string токен
     */
    public static function createResetToken(int $userId): string
    {
        $token = bin2hex(random_bytes(32));
        $pdo = db();
        $pdo->prepare('DELETE FROM password_resets WHERE user_id = :id')->execute([':id' => $userId]);
        $pdo->prepare("INSERT INTO password_resets (user_id, token_hash, expires_at)
                       VALUES (:id, :hash, NOW() + INTERVAL '1 hour')")
            ->execute([':id' => $userId, ':hash' => hash('sha256', $token)]);
        return $token;
    }

    /** id пользователя по действующему токену или null. */
    public static function userIdByToken(string $token): ?int
    {
        $st = db()->prepare('SELECT user_id FROM password_resets WHERE token_hash = :hash AND expires_at > NOW()');
        $st->execute([':hash' => hash('sha256', $token)]);
        $id = $st->fetchColumn();
        return $id === false ? null : (int)$id;
    }
}
