<?php
/**
 * Модель фильмов (основной ресурс приложения): таблица films.
 */
class FilmModel
{
    const CATEGORIES = ['movie' => 'Movie', 'series' => 'TV series', 'animation' => 'Animation'];
    const STATUSES   = ['released' => 'Released', 'upcoming' => 'Upcoming'];

    /** Лучшие по рейтингу (для главной страницы). */
    public static function topRated(int $limit): array
    {
        $limit = (int)$limit;
        return db()->query("SELECT * FROM films WHERE rating IS NOT NULL ORDER BY rating DESC, release_year DESC LIMIT $limit")->fetchAll();
    }

    /** Ожидаемые релизы. */
    public static function upcoming(int $limit): array
    {
        $limit = (int)$limit;
        return db()->query("SELECT * FROM films WHERE status = 'upcoming' ORDER BY release_year, title LIMIT $limit")->fetchAll();
    }

    /** Последние добавленные. */
    public static function latest(int $limit): array
    {
        $limit = (int)$limit;
        return db()->query("SELECT * FROM films ORDER BY created_at DESC, id DESC LIMIT $limit")->fetchAll();
    }

    /** Все фильмы с автором (для админки). */
    public static function all(): array
    {
        return db()->query(
            'SELECT f.*, u.email AS author FROM films f LEFT JOIN users u ON u.id = f.user_id ORDER BY f.id'
        )->fetchAll();
    }

    /** Количество фильмов. */
    public static function count(): int
    {
        return (int)db()->query('SELECT COUNT(*) FROM films')->fetchColumn();
    }

    /** Один фильм по id. */
    public static function find(int $id): ?array
    {
        $st = db()->prepare('SELECT * FROM films WHERE id = :id');
        $st->execute([':id' => $id]);
        return $st->fetch() ?: null;
    }

    /**
     * Поиск фильмов по критериям (форма поиска).
     * @param array $f ['q', 'category', 'status', 'year_from', 'year_to'] — пустые критерии игнорируются
     * @return array
     */
    public static function search(array $f): array
    {
        $where = [];
        $params = [];

        if (($f['q'] ?? '') !== '') {
            $where[] = 'title ILIKE :q';
            $params[':q'] = '%' . addcslashes(mb_substr($f['q'], 0, 100), '%_\\') . '%';
        }
        if (isset(self::CATEGORIES[$f['category'] ?? ''])) {
            $where[] = 'category = :category';
            $params[':category'] = $f['category'];
        }
        if (isset(self::STATUSES[$f['status'] ?? ''])) {
            $where[] = 'status = :status';
            $params[':status'] = $f['status'];
        }
        if (ctype_digit($f['year_from'] ?? '') && strlen($f['year_from']) === 4) {
            $where[] = 'release_year >= :yfrom';
            $params[':yfrom'] = (int)$f['year_from'];
        }
        if (ctype_digit($f['year_to'] ?? '') && strlen($f['year_to']) === 4) {
            $where[] = 'release_year <= :yto';
            $params[':yto'] = (int)$f['year_to'];
        }

        $sql = 'SELECT * FROM films';
        if ($where) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY release_year, title';

        $st = db()->prepare($sql);
        $st->execute($params);
        return $st->fetchAll();
    }

    /**
     * Проверка данных формы фильма на сервере.
     * @param array $in сырые данные ($_POST)
     * @return array [очищенные данные, ошибки]
     */
    public static function validate(array $in): array
    {
        $d = [
            'title'        => clean($in, 'title'),
            'release_year' => clean($in, 'release_year'),
            'category'     => clean($in, 'category'),
            'status'       => clean($in, 'status'),
            'rating'       => clean($in, 'rating'),
            'description'  => clean($in, 'description'),
            'poster'       => clean($in, 'poster'),
        ];
        $errors = [];

        $len = mb_strlen($d['title']);
        if ($len < 2 || $len > 150) {
            $errors['title'] = 'Title must be 2–150 characters long.';
        }

        $year = filter_var($d['release_year'], FILTER_VALIDATE_INT);
        if ($year === false || $year < 1939 || $year > 2100) {
            $errors['release_year'] = 'Year must be a number between 1939 and 2100.';
        }

        if (!isset(self::CATEGORIES[$d['category']])) {
            $errors['category'] = 'Choose a category from the list.';
        }
        if (!isset(self::STATUSES[$d['status']])) {
            $errors['status'] = 'Choose a status.';
        }

        if ($d['rating'] !== '') {
            if (!is_numeric($d['rating']) || $d['rating'] < 0 || $d['rating'] > 10) {
                $errors['rating'] = 'Rating must be a number from 0 to 10.';
            } else {
                $d['rating'] = (string)round((float)$d['rating'], 1);
            }
        }

        $len = mb_strlen($d['description']);
        if ($len < 10 || $len > 2000) {
            $errors['description'] = 'Description must be 10–2000 characters long.';
        }

        if ($d['poster'] !== '') {
            $scheme = strtolower((string)parse_url($d['poster'], PHP_URL_SCHEME));
            if (!filter_var($d['poster'], FILTER_VALIDATE_URL) || !in_array($scheme, ['http', 'https'], true) || strlen($d['poster']) > 500) {
                $errors['poster'] = 'Poster must be a valid http(s) link (up to 500 characters).';
            }
        }

        return [$d, $errors];
    }

    /** Добавляет фильм. @return int id */
    public static function create(array $d, ?int $userId): int
    {
        $st = db()->prepare(
            'INSERT INTO films (title, release_year, category, status, rating, description, poster, user_id)
             VALUES (:title, :year, :category, :status, :rating, :description, :poster, :user) RETURNING id'
        );
        $st->execute(self::params($d) + [':user' => $userId]);
        return (int)$st->fetchColumn();
    }

    /** Обновляет фильм. */
    public static function update(int $id, array $d): void
    {
        $st = db()->prepare(
            'UPDATE films SET title = :title, release_year = :year, category = :category, status = :status,
                              rating = :rating, description = :description, poster = :poster
             WHERE id = :id'
        );
        $st->execute(self::params($d) + [':id' => $id]);
    }

    /** Удаляет фильм. */
    public static function delete(int $id): void
    {
        $st = db()->prepare('DELETE FROM films WHERE id = :id');
        $st->execute([':id' => $id]);
    }

    /** Параметры запроса из очищенных данных (пустые необязательные поля -> NULL). */
    private static function params(array $d): array
    {
        return [
            ':title'       => $d['title'],
            ':year'        => (int)$d['release_year'],
            ':category'    => $d['category'],
            ':status'      => $d['status'],
            ':rating'      => $d['rating'] !== '' ? $d['rating'] : null,
            ':description' => $d['description'],
            ':poster'      => $d['poster'] !== '' ? $d['poster'] : null,
        ];
    }
}
