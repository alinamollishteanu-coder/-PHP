<?php
/**
 * Настройки приложения.
 */
return [
    // Подключение к PostgreSQL (контейнер из docker-compose.yml)
    'db' => [
        'host' => '127.0.0.1',
        'port' => 5433,
        'name' => 'marvel',
        'user' => 'marvel',
        'pass' => 'marvel_pass',
    ],
    // Адрес сайта — используется для ссылки восстановления пароля
    'base_url' => 'http://localhost:8000',
    // true — показывать подробные ошибки и ссылку для сброса пароля прямо на сайте (только для разработки!)
    'debug' => true,
    // Математическая CAPTCHA на формах входа и регистрации
    'captcha' => true,
    // false — письма пишутся только в storage/mail.log; true — дополнительно отправляются через mail()
    'mail_real' => false,
    'mail_from' => 'no-reply@marvel.local',
];
