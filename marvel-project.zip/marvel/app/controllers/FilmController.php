<?php
/**
 * Фильмы: публичный список с поиском и форма добавления (для вошедших пользователей).
 */
class FilmController
{
    /** Публичный список фильмов + форма поиска (GET-параметры). */
    public function index(): void
    {
        $f = [
            'q'         => clean($_GET, 'q'),
            'category'  => clean($_GET, 'category'),
            'status'    => clean($_GET, 'status'),
            'year_from' => clean($_GET, 'year_from'),
            'year_to'   => clean($_GET, 'year_to'),
        ];
        render('films', ['title' => 'Films', 'f' => $f, 'films' => FilmModel::search($f)]);
    }

    /** Форма создания фильма (только для авторизованных). */
    public function create(): void
    {
        require_login();
        $values = ['title' => '', 'release_year' => '', 'category' => 'movie', 'status' => 'released',
                   'rating' => '', 'description' => '', 'poster' => ''];
        $errors = [];

        if (is_post()) {
            csrf_check();
            [$values, $errors] = FilmModel::validate($_POST);
            if (!$errors) {
                FilmModel::create($values, (int)current_user()['id']);
                flash('success', 'Film added.');
                redirect('films');
            }
        }
        render('film_form', [
            'title'   => 'Add a film',
            'heading' => 'Add a film',
            'action'  => url('film_add'),
            'submit'  => 'Add film',
            'values'  => $values,
            'errors'  => $errors,
        ]);
    }
}
