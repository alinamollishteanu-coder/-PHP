<?php
/**
 * Панель администратора. Каждый метод начинается с require_admin().
 * Функции: статистика, управление фильмами (просмотр/изменение/удаление),
 * управление пользователями (просмотр, смена роли, удаление), создание новых администраторов.
 */
class AdminController
{
    /** Главная страница админки со статистикой. */
    public function dashboard(): void
    {
        require_admin();
        render('admin/dashboard', [
            'title'  => 'Admin panel',
            'users'  => UserModel::counts(),
            'films'  => FilmModel::count(),
        ]);
    }

    /** Таблица всех фильмов. */
    public function films(): void
    {
        require_admin();
        render('admin/films', ['title' => 'Manage films', 'films' => FilmModel::all()]);
    }

    /** Редактирование фильма. */
    public function filmEdit(): void
    {
        require_admin();
        $id = (int)clean($_GET, 'id');
        $film = FilmModel::find($id);
        if (!$film) {
            flash('error', 'Film not found.');
            redirect('admin_films');
        }
        $values = $film;
        $errors = [];

        if (is_post()) {
            csrf_check();
            [$values, $errors] = FilmModel::validate($_POST);
            if (!$errors) {
                FilmModel::update($id, $values);
                flash('success', 'Film updated.');
                redirect('admin_films');
            }
        }
        render('film_form', [
            'title'   => 'Edit film',
            'heading' => 'Edit film #' . $id,
            'action'  => url('admin_film_edit', ['id' => $id]),
            'submit'  => 'Save changes',
            'values'  => $values,
            'errors'  => $errors,
        ]);
    }

    /** Удаление фильма (только POST). */
    public function filmDelete(): void
    {
        require_admin();
        if (is_post()) {
            csrf_check();
            FilmModel::delete((int)clean($_POST, 'id'));
            flash('success', 'Film deleted.');
        }
        redirect('admin_films');
    }

    /** Таблица пользователей. */
    public function users(): void
    {
        require_admin();
        render('admin/users', ['title' => 'Manage users', 'users' => UserModel::all()]);
    }

    /** Создание новой учётной записи с ролью администратора. */
    public function userAdd(): void
    {
        require_admin();
        $values = ['surname' => '', 'name' => '', 'email' => '', 'birth' => '', 'gender' => '', 'phone' => ''];
        $errors = [];

        if (is_post()) {
            csrf_check();
            [$values, $errors] = UserModel::validate($_POST);
            if (!$errors) {
                UserModel::create($values, 'admin');
                flash('success', 'New administrator account created.');
                redirect('admin_users');
            }
        }
        render('admin/user_add', ['title' => 'New administrator', 'values' => $values, 'errors' => $errors]);
    }

    /** Смена роли пользователя (только POST). Свою роль менять нельзя. */
    public function userRole(): void
    {
        require_admin();
        if (is_post()) {
            csrf_check();
            $id = (int)clean($_POST, 'id');
            $role = clean($_POST, 'role');
            if ($id === (int)current_user()['id']) {
                flash('error', 'You cannot change your own role.');
            } elseif (!in_array($role, ['user', 'admin'], true) || !UserModel::find($id)) {
                flash('error', 'Invalid request.');
            } else {
                UserModel::setRole($id, $role);
                flash('success', 'Role updated.');
            }
        }
        redirect('admin_users');
    }

    /** Удаление пользователя (только POST). Себя удалить нельзя. */
    public function userDelete(): void
    {
        require_admin();
        if (is_post()) {
            csrf_check();
            $id = (int)clean($_POST, 'id');
            if ($id === (int)current_user()['id']) {
                flash('error', 'You cannot delete your own account.');
            } elseif (!UserModel::find($id)) {
                flash('error', 'User not found.');
            } else {
                UserModel::delete($id);
                flash('success', 'User deleted.');
            }
        }
        redirect('admin_users');
    }
}
