<?php
/**
 * Публичные страницы: главная (данные из БД) и история Marvel.
 */
class HomeController
{
    /** Главная: лучшие фильмы, ожидаемые релизы, последние добавленные — всё из БД. */
    public function index(): void
    {
        render('home', [
            'title'    => 'Marvel Universe',
            'top'      => FilmModel::topRated(4),
            'upcoming' => FilmModel::upcoming(5),
            'latest'   => FilmModel::latest(3),
        ]);
    }

    /** История Marvel (статическая страница). */
    public function history(): void
    {
        render('history', ['title' => 'Marvel Creation Story']);
    }
}
