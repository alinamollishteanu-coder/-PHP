<?php
/**
 * Аутентификация: регистрация, вход, выход, восстановление пароля.
 */
class AuthController
{
    /** Регистрация нового пользователя. */
    public function register(): void
    {
        if (current_user()) {
            redirect('home');
        }
        $values = ['surname' => '', 'name' => '', 'email' => '', 'birth' => '', 'gender' => '', 'phone' => ''];
        $errors = [];

        if (is_post()) {
            csrf_check();
            [$values, $errors] = UserModel::validate($_POST);
            if (captcha_enabled() && !captcha_check(clean($_POST, 'captcha'))) {
                $errors['captcha'] = 'Wrong answer, try the new example.';
            }
            if (!$errors) {
                UserModel::create($values, 'user');
                flash('success', 'Registration completed. You can log in now.');
                redirect('login');
            }
        }
        render('register', ['title' => 'Registration', 'values' => $values, 'errors' => $errors]);
    }

    /** Вход в систему. */
    public function login(): void
    {
        if (current_user()) {
            redirect('home');
        }
        $values = ['email' => ''];
        $errors = [];

        if (is_post()) {
            csrf_check();
            $values['email'] = mb_strtolower(clean($_POST, 'email'));
            if (captcha_enabled() && !captcha_check(clean($_POST, 'captcha'))) {
                $errors['captcha'] = 'Wrong answer, try the new example.';
            } else {
                $user = UserModel::findByEmail($values['email']);
                if ($user && password_verify(raw($_POST, 'password'), $user['password_hash'])) {
                    session_regenerate_id(true);          // защита от фиксации сессии
                    $_SESSION['user_id'] = (int)$user['id'];
                    flash('success', 'Welcome, ' . $user['name'] . '!');
                    redirect($user['role'] === 'admin' ? 'admin' : 'home');
                }
                $errors['form'] = 'Wrong e-mail or password.';
            }
        }
        render('login', ['title' => 'Log in', 'values' => $values, 'errors' => $errors]);
    }

    /** Выход. */
    public function logout(): void
    {
        unset($_SESSION['user_id']);
        session_regenerate_id(true);
        flash('success', 'You have logged out.');
        redirect('home');
    }

    /** Запрос ссылки для восстановления пароля. */
    public function forgot(): void
    {
        $values = ['email' => ''];
        $errors = [];

        if (is_post()) {
            csrf_check();
            $email = mb_strtolower(clean($_POST, 'email'));
            $values['email'] = $email;

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors['email'] = 'Enter a valid e-mail address.';
            } else {
                $user = UserModel::findByEmail($email);
                if ($user) {
                    $token = UserModel::createResetToken((int)$user['id']);
                    $link = rtrim(config()['base_url'], '/') . '/index.php?page=reset&token=' . $token;
                    send_mail(
                        $user['email'],
                        'Password reset',
                        "Hello, {$user['name']}!\n\nTo set a new password open this link (valid for 1 hour):\n$link\n"
                    );
                    if (config()['debug']) {
                        flash('info', 'DEV MODE: the e-mail was saved to storage/mail.log. Reset link:', $link);
                    }
                }
                // Одинаковый ответ для существующих и несуществующих адресов
                flash('success', 'If this e-mail is registered, a password reset link has been sent to it.');
                redirect('login');
            }
        }
        render('forgot', ['title' => 'Password recovery', 'values' => $values, 'errors' => $errors]);
    }

    /** Установка нового пароля по ссылке из письма. */
    public function reset(): void
    {
        $token = clean($_GET, 'token') ?: clean($_POST, 'token');
        $userId = preg_match('/^[a-f0-9]{64}$/', $token) ? UserModel::userIdByToken($token) : null;
        if ($userId === null) {
            flash('error', 'This reset link is invalid or has expired.');
            redirect('forgot');
        }

        $errors = [];
        if (is_post()) {
            csrf_check();
            $errors = UserModel::passwordErrors(raw($_POST, 'password'), raw($_POST, 'password2'));
            if (!$errors) {
                UserModel::updatePassword($userId, raw($_POST, 'password'));
                flash('success', 'Password changed. You can log in now.');
                redirect('login');
            }
        }
        render('reset', ['title' => 'New password', 'token' => $token, 'errors' => $errors]);
    }
}
