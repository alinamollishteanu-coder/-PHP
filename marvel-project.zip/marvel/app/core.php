<?php
/**
 * core.php — общие функции приложения: БД, сессии, защита (XSS, CSRF), авторизация, шаблоны.
 */

define('ROOT_PATH', dirname(__DIR__));
define('APP_PATH', __DIR__);
define('VIEW_PATH', __DIR__ . '/views');

/** Автозагрузка классов из папок models и controllers. */
spl_autoload_register(function (string $class): void {
    foreach (['models', 'controllers'] as $dir) {
        $file = APP_PATH . '/' . $dir . '/' . $class . '.php';
        if (is_file($file)) {
            require $file;
            return;
        }
    }
});

/** Безопасные настройки сессии + защитные заголовки. */
session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax']);
session_start();
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');

/**
 * Возвращает настройки из config.php.
 * @return array
 */
function config(): array
{
    static $cfg = null;
    if ($cfg === null) {
        $cfg = require APP_PATH . '/config.php';
    }
    return $cfg;
}

/**
 * Подключение к PostgreSQL через PDO (создаётся один раз).
 * Все запросы в моделях — подготовленные (защита от SQL-инъекций).
 * @return PDO
 */
function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $c = config()['db'];
        $dsn = "pgsql:host={$c['host']};port={$c['port']};dbname={$c['name']}";
        $pdo = new PDO($dsn, $c['user'], $c['pass'], [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    }
    return $pdo;
}

/* ---------- Вывод и ввод ---------- */

/**
 * Экранирование строки для вывода в HTML (защита от XSS).
 * @param mixed $value
 * @return string
 */
function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/**
 * Значение текстового поля из массива ($_POST / $_GET): строка без пробелов по краям.
 * Если пришёл не текст (например, массив) — вернётся пустая строка.
 * @param array  $src
 * @param string $key
 * @return string
 */
function clean(array $src, string $key): string
{
    $v = $src[$key] ?? '';
    return is_string($v) ? trim($v) : '';
}

/**
 * Значение «как есть» (для паролей — пробелы не обрезаем).
 * @param array  $src
 * @param string $key
 * @return string
 */
function raw(array $src, string $key): string
{
    $v = $src[$key] ?? '';
    return is_string($v) ? $v : '';
}

/** Экранированное старое значение поля формы. */
function old(array $values, string $key): string
{
    return e($values[$key] ?? '');
}

/** HTML-блок с текстом ошибки поля (если ошибка есть). */
function err(array $errors, string $key): string
{
    return isset($errors[$key]) ? '<span class="err">' . e($errors[$key]) . '</span>' : '';
}

/** Запрос отправлен методом POST? */
function is_post(): bool
{
    return $_SERVER['REQUEST_METHOD'] === 'POST';
}

/* ---------- Маршруты и шаблоны ---------- */

/**
 * Ссылка на страницу приложения.
 * @param string $page   имя маршрута
 * @param array  $params дополнительные GET-параметры
 * @return string
 */
function url(string $page, array $params = []): string
{
    return 'index.php?' . http_build_query(['page' => $page] + $params);
}

/** Перенаправление на страницу приложения и завершение скрипта. */
function redirect(string $page, array $params = []): void
{
    header('Location: ' . url($page, $params));
    exit;
}

/**
 * Показывает представление (view) внутри общего оформления (шапка + подвал).
 * @param string $view имя файла в app/views без .php
 * @param array  $data переменные для шаблона
 */
function render(string $view, array $data = []): void
{
    extract($data, EXTR_SKIP);
    require VIEW_PATH . '/layout/header.php';
    require VIEW_PATH . '/' . $view . '.php';
    require VIEW_PATH . '/layout/footer.php';
}

/* ---------- Flash-сообщения ---------- */

/** Запоминает сообщение, которое будет показано на следующей странице. */
function flash(string $type, string $msg, ?string $link = null): void
{
    $_SESSION['flash'][] = ['type' => $type, 'msg' => $msg, 'link' => $link];
}

/** Возвращает и очищает накопленные flash-сообщения. */
function take_flash(): array
{
    $list = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $list;
}

/* ---------- CSRF ---------- */

/** Токен защиты форм от CSRF (хранится в сессии). */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

/** Скрытое поле с CSRF-токеном — вставляется в каждую POST-форму. */
function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

/** Проверка CSRF-токена в POST-запросе; при ошибке — остановка с кодом 400. */
function csrf_check(): void
{
    $t = $_POST['csrf'] ?? '';
    if (!is_string($t) || !hash_equals(csrf_token(), $t)) {
        http_response_code(400);
        exit('Invalid CSRF token. Please go back, reload the page and try again.');
    }
}

/* ---------- Авторизация ---------- */

/**
 * Текущий пользователь (строка из БД) или null, если не вошёл.
 * Роль берётся из БД при каждом запросе, поэтому смена роли действует сразу.
 * @return array|null
 */
function current_user(): ?array
{
    static $user = false;
    if ($user === false) {
        $user = null;
        if (!empty($_SESSION['user_id'])) {
            try {
                $user = UserModel::find((int)$_SESSION['user_id']);
            } catch (PDOException $ex) {
                $user = null;
            }
            if ($user === null) {
                unset($_SESSION['user_id']);
            }
        }
    }
    return $user;
}

/** Доступ только для вошедших пользователей. */
function require_login(): void
{
    if (!current_user()) {
        flash('error', 'Please log in to open this page.');
        redirect('login');
    }
}

/** Доступ только для администраторов. */
function require_admin(): void
{
    require_login();
    if (current_user()['role'] !== 'admin') {
        http_response_code(403);
        render('error', ['title' => 'Forbidden', 'code' => 403, 'message' => 'Only administrators can open this page.']);
        exit;
    }
}

/* ---------- CAPTCHA (простая математическая) ---------- */

/** Включена ли CAPTCHA в config.php. */
function captcha_enabled(): bool
{
    return (bool)config()['captcha'];
}

/** Текст примера, например «3 + 7». Ответ хранится в сессии. */
function captcha_question(): string
{
    if (empty($_SESSION['captcha_q'])) {
        $a = random_int(1, 9);
        $b = random_int(1, 9);
        $_SESSION['captcha_q'] = "$a + $b";
        $_SESSION['captcha_a'] = $a + $b;
    }
    return $_SESSION['captcha_q'];
}

/** Проверяет ответ; после проверки пример сбрасывается (каждый пример — одноразовый). */
function captcha_check(string $answer): bool
{
    $ok = isset($_SESSION['captcha_a']) && ctype_digit($answer) && (int)$answer === $_SESSION['captcha_a'];
    unset($_SESSION['captcha_q'], $_SESSION['captcha_a']);
    return $ok;
}

/* ---------- Почта ---------- */

/**
 * «Отправка» письма. Письмо всегда записывается в storage/mail.log,
 * а при mail_real=true дополнительно уходит через mail().
 */
function send_mail(string $to, string $subject, string $body): void
{
    $dir = ROOT_PATH . '/storage';
    if (!is_dir($dir)) {
        mkdir($dir, 0775, true);
    }
    $line = '[' . date('Y-m-d H:i:s') . "] To: $to | Subject: $subject\n$body\n" . str_repeat('-', 60) . "\n";
    file_put_contents($dir . '/mail.log', $line, FILE_APPEND);
    if (config()['mail_real']) {
        @mail($to, $subject, $body, 'From: ' . config()['mail_from']);
    }
}
