// Клиентская проверка форм (дополняет HTML5-атрибуты required, pattern, min, max и т.д.).
// Сервер всё равно перепроверяет данные — клиентская проверка нужна для удобства пользователя.
document.addEventListener('DOMContentLoaded', function () {

    // Пароль: буква + цифра, и совпадение с повтором
    document.querySelectorAll('form[data-validate]').forEach(function (form) {
        var pass = form.querySelector('[name="password"]');
        var pass2 = form.querySelector('[name="password2"]');
        if (!pass) { return; }

        function check() {
            var weak = pass.value !== '' && !(/[A-Za-z]/.test(pass.value) && /[0-9]/.test(pass.value));
            pass.setCustomValidity(weak ? 'Password must contain at least one letter and one digit.' : '');
            if (pass2) {
                pass2.setCustomValidity(pass2.value !== pass.value ? 'Passwords do not match.' : '');
            }
        }
        pass.addEventListener('input', check);
        if (pass2) { pass2.addEventListener('input', check); }
    });

    // Понятные сообщения для полей с pattern (атрибут data-msg)
    document.querySelectorAll('input[data-msg]').forEach(function (input) {
        input.addEventListener('invalid', function () {
            input.setCustomValidity('');
            if (!input.validity.valid) { input.setCustomValidity(input.dataset.msg); }
        });
        input.addEventListener('input', function () { input.setCustomValidity(''); });
    });
});
