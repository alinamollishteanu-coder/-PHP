<?php
/**
 * Единая точка входа (front controller).
 * Адреса вида index.php?page=films подбирают контроллер и метод из таблицы маршрутов.
 */
require __DIR__ . '/../app/core.php';

// страница => [контроллер, метод]
$routes = [
    'home'              => ['HomeController',  'index'],
    'history'           => ['HomeController',  'history'],
    'films'             => ['FilmController',  'index'],        // публично: список + поиск
    'film_add'          => ['FilmController',  'create'],       // только для вошедших
    'register'          => ['AuthController',  'register'],
    'login'             => ['AuthController',  'login'],
    'logout'            => ['AuthController',  'logout'],
    'forgot'            => ['AuthController',  'forgot'],
    'reset'             => ['AuthController',  'reset'],
    'admin'             => ['AdminController', 'dashboard'],    // дальше — только для администратора
    'admin_films'       => ['AdminController', 'films'],
    'admin_film_edit'   => ['AdminController', 'filmEdit'],
    'admin_film_delete' => ['AdminController', 'filmDelete'],
    'admin_users'       => ['AdminController', 'users'],
    'admin_user_add'    => ['AdminController', 'userAdd'],
    'admin_user_role'   => ['AdminController', 'userRole'],
    'admin_user_delete' => ['AdminController', 'userDelete'],
];

$page = $_GET['page'] ?? 'home';

if (!is_string($page) || !isset($routes[$page])) {
    http_response_code(404);
    render('error', ['title' => 'Not found', 'code' => 404, 'message' => 'This page does not exist.']);
    exit;
}

[$class, $method] = $routes[$page];

try {
    (new $class())->$method();
} catch (PDOException $ex) {
    http_response_code(500);
    $msg = config()['debug']
        ? 'Database error: ' . $ex->getMessage()
        : 'Something went wrong. Please try again later.';
    render('error', ['title' => 'Error', 'code' => 500, 'message' => $msg]);
}
