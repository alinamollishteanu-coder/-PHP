-- Схема БД и тестовые данные. Выполняется автоматически при первом запуске контейнера.

CREATE EXTENSION IF NOT EXISTS pgcrypto;   -- нужен только для создания хеша пароля админа ниже

CREATE TABLE users (
    id            SERIAL PRIMARY KEY,
    surname       VARCHAR(50)  NOT NULL,
    name          VARCHAR(50)  NOT NULL,
    email         VARCHAR(100) NOT NULL UNIQUE,
    birth         DATE         NOT NULL,
    gender        CHAR(1)      CHECK (gender IN ('M', 'F')),
    phone         VARCHAR(20),
    password_hash VARCHAR(255) NOT NULL,
    role          VARCHAR(10)  NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
    created_at    TIMESTAMP    NOT NULL DEFAULT NOW()
);

-- Токены восстановления пароля (хранится только хеш токена)
CREATE TABLE password_resets (
    id         SERIAL PRIMARY KEY,
    user_id    INT         NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash VARCHAR(64) NOT NULL,
    expires_at TIMESTAMP   NOT NULL
);

-- Основной ресурс приложения: фильмы / сериалы Marvel
CREATE TABLE films (
    id           SERIAL PRIMARY KEY,
    title        VARCHAR(150) NOT NULL,
    release_year SMALLINT     NOT NULL CHECK (release_year BETWEEN 1939 AND 2100),
    category     VARCHAR(20)  NOT NULL CHECK (category IN ('movie', 'series', 'animation')),
    status       VARCHAR(10)  NOT NULL CHECK (status IN ('released', 'upcoming')),
    rating       NUMERIC(3,1) CHECK (rating BETWEEN 0 AND 10),
    description  TEXT         NOT NULL,
    poster       VARCHAR(500),
    user_id      INT REFERENCES users(id) ON DELETE SET NULL,
    created_at   TIMESTAMP    NOT NULL DEFAULT NOW()
);

-- Администратор по умолчанию:  admin@marvel.local / Admin123!
INSERT INTO users (surname, name, email, birth, password_hash, role)
VALUES ('Admin', 'Admin', 'admin@marvel.local', '1990-01-01', crypt('Admin123!', gen_salt('bf', 10)), 'admin');

INSERT INTO films (title, release_year, category, status, rating, description, poster) VALUES
('Captain America: The First Avenger', 2011, 'movie', 'released', 6.9,
 'Steve Rogers becomes Captain America during World War II, battling the Nazi organization HYDRA led by the Red Skull.',
 'https://m.media-amazon.com/images/M/MV5BMTYzOTc2NzU3N15BMl5BanBnXkFtZTcwNjY3MDE3NQ@@._V1_.jpg'),
('Iron Man', 2008, 'movie', 'released', 7.9,
 'Tony Stark builds a powered suit of armor after being captured by terrorists, becoming the superhero Iron Man.',
 'https://m.media-amazon.com/images/M/MV5BMTczNTI2ODUwOF5BMl5BanBnXkFtZTcwMTU0NTIzMw@@._V1_.jpg'),
('Iron Man 2', 2010, 'movie', 'released', 6.9,
 'Tony Stark faces pressure from the government to share his technology while battling a Russian physicist turned villain.',
 'https://m.media-amazon.com/images/M/MV5BMTM0MDgwNjMyMl5BMl5BanBnXkFtZTcwNTg3NzAzMw@@._V1_.jpg'),
('The Incredible Hulk', 2008, 'movie', 'released', 6.6,
 'Bruce Banner seeks a cure for his condition while being pursued by General Ross and facing a new threat, the Abomination.',
 'https://m.media-amazon.com/images/M/MV5BMTUyNzk3MjA1OF5BMl5BanBnXkFtZTcwMTE1Njg2MQ@@._V1_.jpg'),
('Thor', 2011, 'movie', 'released', 7.0,
 'The powerful but arrogant god Thor is cast out of Asgard to live among humans, where he learns humility and becomes a true hero.',
 'https://m.media-amazon.com/images/M/MV5BOGE4NzU1YTAtNzA3Mi00ZTA2LTg2YmYtMDJmMThiMjlkYjg2XkEyXkFqcGdeQXVyNTgzMDMzMTg@._V1_.jpg'),
('The Avengers', 2012, 'movie', 'released', 8.0,
 'Nick Fury recruits Iron Man, Captain America, Hulk, Thor, Black Widow, and Hawkeye to form a team that must stop Loki from subjugating Earth.',
 'https://m.media-amazon.com/images/M/MV5BNDYxNjQyMjAtNTdiOS00NGYwLWFmNTAtNThmYjU5ZGI2YTI1XkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_.jpg'),
('Avengers: Age of Ultron', 2015, 'movie', 'released', 7.3,
 'The Avengers battle Ultron, a sentient AI created by Tony Stark that intends to bring about human extinction.',
 'https://m.media-amazon.com/images/M/MV5BMTM4OGJmNWMtOTM4Ni00NTE3LTg3MDItZmQxYjc4N2JhNmUxXkEyXkFqcGdeQXVyNTgzMDMzMTg@._V1_.jpg'),
('Avengers: Infinity War', 2018, 'movie', 'released', 8.4,
 'The Avengers and their allies must be willing to sacrifice all in an attempt to defeat the powerful Thanos before his blitz of devastation ends half the universe.',
 'https://m.media-amazon.com/images/M/MV5BMjMxNjY2MDU1OV5BMl5BanBnXkFtZTgwNzY1MTUwNTM@._V1_.jpg'),
('Avengers: Endgame', 2019, 'movie', 'released', 8.4,
 'After the devastating events of Infinity War, the Avengers assemble one last time to reverse Thanos'' actions and restore order to the universe.',
 'https://m.media-amazon.com/images/M/MV5BMTc5MDE2ODcwNV5BMl5BanBnXkFtZTgwMzI2NzQ2NzM@._V1_.jpg'),
('Avengers: Doomsday', 2026, 'movie', 'upcoming', NULL,
 'The next chapter in the Avengers saga with new threats and new team dynamics.', NULL),
('Avengers: Secret Wars', 2027, 'movie', 'upcoming', NULL,
 'The following Avengers film that continues the multiverse storyline of the Marvel Cinematic Universe.', NULL);
